bottleneckdist<-function(x){
  
  #x is a list created with the perhomology function
  
  if ("perhomology" %in% class(x)) {} else {stop("x must be a perhomology object")}
  
  n<-length(x)
  
  distance<-matrix(nrow=n, ncol=n)
  colnames(distance)<-names(x)
  rownames(distance)<-names(x)
  
  for (r in 1:n){
    
    for (c in r:n){
      
      distance[r,c]<-bottleneck(Diag1=x[[r]], Diag2=x[[c]], dimension=0)} #From TDA package
    
    distance[,r]<-t(distance[r,])} #Because the matrix is symmetric
  
  return(distance)}