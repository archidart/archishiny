rsmlToTable<-function(inputrsml, unitlength="px", rsml.date=NULL, rsml.connect=TRUE, vertical3d="y", unitangle="d", fitter=FALSE){

  if (mode(inputrsml)!="character"){stop("mode(inputrsml) must be character")}
  
  if (mode(unitlength)!="character"){stop("mode(unitlength) must be character")}
  if (unitlength=="px"|unitlength=="mm"|unitlength=="cm") {} else {stop("unitlength must be either px (pixels), mm (millimeters) or cm (centimeters)")}
  
  if (is.null(rsml.date)==FALSE){
    if (is.character(rsml.date)==TRUE|is.numeric(rsml.date)==TRUE){} else {stop("If rsml.date is not NULL, rsml.date must be a character string or a positive numeric value")}
    if (is.numeric(rsml.date)==TRUE){if (rsml.date<=0|length(rsml.date)>1){stop("If mode(rsml.date) is numeric, rsml.date must be a single positive value")}}}
  
  if (mode(rsml.connect)!="logical"){stop("mode(rsml.connect) must be logical")}
  
  if (vertical3d=="x"|vertical3d=="y"|vertical3d=="z") {} else {stop("vertical3d must be x, y, or z")}
  
  if (mode(unitangle)!="character"){stop("mode(unitangle) must be character")}
  if(unitangle=="d"|unitangle=="r") {} else {stop("unitangle must be either d (degrees) or r (radians)")}
  
  if (mode(fitter)!="logical"){stop("fitter must be logical")}
  
  if (fitter==TRUE & rsml.connect==FALSE){stop("If fitter is TRUE, rsml.connect must be TRUE too")}
  
  #Load rsml files
  
  filenames.rsml<-list.files(path=inputrsml, pattern="\\.rsml$")
  path.rsml<-rep(inputrsml, length.out=length(filenames.rsml))
  filenamesrsml<-sub(x=filenames.rsml, pattern="\\.rsml$", replacement="")
  message(paste("Number of rsml files in inputrsml:", length(filenames.rsml), sep=" "))
  
  RSML <- lapply(paste(path.rsml, "/", filenames.rsml, sep=""), rsmlToDART, final.date=rsml.date, connect=rsml.connect) # Read RSML files
  
  res1<-c()
  unitlength1<-c()
  filenamesrac<-c()
  nodes<-0 #nodes is the number of rows (sum rows of each lie)

  for (i in 1:length(RSML)){
    
    res1<-append(res1, rep(as.numeric(RSML[[i]]$resolution), length(RSML[[i]]$lie)))
    filenamesrac<-append(filenamesrac, rep(filenamesrsml[i], length(RSML[[i]]$lie)))
    unitlength1<-append(unitlength1, rep(as.character(RSML[[i]]$length), length(RSML[[i]]$lie)))
    for (j in 1:length(RSML[[i]]$lie)) {nodes<-nodes+nrow(RSML[[i]]$lie[[j]])}}
  
  #Unit conversion RSML
  cunit1<-vector(length=length(res1))
  
  for (i in 1:length(res1)){
    
    if (unitlength=="cm"){
      
      if (unitlength1[i]=="pixel") {
        cunit1[i]<-1
        message(paste("Unit in ", filenamesrac[i], " is pixel. Unitlength not used and results expressed in pixels", sep=""))}
      if (unitlength1[i]=="m") {cunit1[i]<-100/res1[i]}
      if (unitlength1[i]=="cm") {cunit1[i]<-1/res1[i]}
      if (unitlength1[i]=="mm") {cunit1[i]<-1/res1[i]/10}
      if (unitlength1[i]=="um") {cunit1[i]<-1/res1[i]/10000}
      if (unitlength1[i]=="nm") {cunit1[i]<-1/res1[i]/10000000}
      if (unitlength1[i]=="inch") {cunit1[i]<-1/res1[i]*cm(1)}}
    
    if (unitlength=="mm"){
      if (unitlength1[i]=="pixel") {
        cunit1[i]<-1
        message(paste("Unit in ", filenamesrac[i], " is pixel. Unitlength not used and results expressed in pixels", sep=""))}
      if (unitlength1[i]=="m") {cunit1[i]<-1/res1[i]*1000}
      if (unitlength1[i]=="cm") {cunit1[i]<-1/res1[i]*10}
      if (unitlength1[i]=="mm") {cunit1[i]<-1/res1[i]}
      if (unitlength1[i]=="um") {cunit1[i]<-1/res1[i]/1000}
      if (unitlength1[i]=="nm") {cunit1[i]<-1/res1[i]/1000000}
      if (unitlength1[i]=="inch") {cunit1[i]<-1/res1[i]*cm(1)*10}}
    
    if (unitlength=="px"){cunit1[i]<-1}}
  
  # Vertical direction vector
  
  if (vertical3d=="x") {dirvert<-c(1,0,0)}
  if (vertical3d=="y") {dirvert<-c(0,1,0)}
  if (vertical3d=="z") {dirvert<-c(0,0,1)}
  
  if (unitangle=="r") {cunitangle<-1}
  if (unitangle=="d") {cunitangle<-180/pi}
  
  #Construct rsml table (1 line per segment)
  
  if (rsml.connect==TRUE) {table<-data.frame(file=rep(NA, nodes), plant=rep(NA, nodes), root=rep(NA, nodes), dbase=rep(NA, nodes), dbasecum=rep(NA, nodes), order=rep(NA, nodes), time=rep(NA, nodes), deltaage=rep(NA, nodes), bran=rep(NA, nodes), apic=rep(NA, nodes), x1=rep(NA, nodes), y1=rep(NA, nodes), z1=rep(NA, nodes), x2=rep(NA, nodes), y2=rep(NA, nodes), z2=rep(NA, nodes), diameter1=rep(NA, nodes), diameter2=rep(NA, nodes), length=rep(NA, nodes), blength=rep(NA, nodes), orientation=rep(NA, nodes), growth=rep(NA, nodes), geodesic=rep(NA, nodes))}
  if (rsml.connect==FALSE) {table<-data.frame(file=rep(NA, nodes), plant=rep(NA, nodes), root=rep(NA, nodes), order=rep(NA, nodes), time=rep(NA, nodes), deltaage=rep(NA, nodes), bran=rep(NA, nodes), apic=rep(NA, nodes), x1=rep(NA, nodes), y1=rep(NA, nodes), z1=rep(NA, nodes), x2=rep(NA, nodes), y2=rep(NA, nodes), z2=rep(NA, nodes), diameter1=rep(NA, nodes), diameter2=rep(NA, nodes), length=rep(NA, nodes), blength=rep(NA, nodes), orientation=rep(NA, nodes), growth=rep(NA, nodes))}
  
  rowsintable<-0
  n<-0 #n is the number of lie files
  
  for (i in 1:length(RSML)){ #For each rsml
    
    for (j in 1:length(RSML[[i]]$lie)){ #For each plant in rsml
      
      n<-n+1
      lie<-RSML[[i]]$lie[[j]]
      if (rsml.connect==TRUE) {rac<-RSML[[i]]$rac[[j]]}
      tps<-RSML[[i]]$tps[[j]]
      
      if ("Z" %in% colnames(lie)) {} else {dirvert<-c(0,1)}
      
      #Add dbasecum column in rac file
      
      if (rsml.connect==TRUE){
      
        rac$CumDBase<-rep(NA, nrow(rac))
      
        for (l in 1:nrow(rac)){
        
          if (rac$Ord[l]==1) {rac$CumDBase[l]<-0}
          else {rac$CumDBase[l]<-rac$CumDBase[rac$Mother[l]+1]+rac$DBase[l]}}}
      
      
      s<-0 #Count number of segments added to table
      
      for (l in 1:nrow(lie)){ #For each line in rsml
        
        if (lie$Prec[l]!=0){
          
          s<-s+1
          prec<-lie$Prec[l]
          table$file[rowsintable+s]<-filenamesrsml[i]
          table$plant[rowsintable+s]<-j
          table$root[rowsintable+s]<-lie$root[l]
          if (rsml.connect==TRUE) {table$dbase[rowsintable+s]<-rac$DBase[lie$root[l]]*cunit1[n]}
          if (rsml.connect==TRUE) {table$dbasecum[rowsintable+s]<-rac$CumDBase[lie$root[l]]*cunit1[n]}
          table$order[rowsintable+s]<-lie$ord[l]
          table$time[rowsintable+s]<-tps$Date[lie$Date[l]]
          if (lie$Bran[prec]=="true" & lie$ord[l]==1) {table$bran[rowsintable+s]<-lie$Bran[prec]} else {table$bran[rowsintable+s]<-lie$Bran[l]}
          table$apic[rowsintable+s]<-lie$Apic[l]
          
          if (tps$Date[lie$Date[l]]!=min(tps$Date)) {table$deltaage[rowsintable+s]<-tps$Date[lie$Date[l]]-tps$Date[lie$Date[l]-1]} else {table$deltaage[rowsintable+s]<-tps$Date[lie$Date[l]]}
          
          table$x1[rowsintable+s]<-lie$X[prec]*cunit1[n]
          table$y1[rowsintable+s]<-lie$Y[prec]*cunit1[n]
          if ("Z" %in% colnames(lie)) {table$z1[rowsintable+s]<-lie$Z[prec]*cunit1[n]} else {table$z1[rowsintable+s]<-0}
          
          table$x2[rowsintable+s]<-lie$X[l]*cunit1[n]
          table$y2[rowsintable+s]<-lie$Y[l]*cunit1[n]
          if ("Z" %in% colnames(lie)) {table$z2[rowsintable+s]<-lie$Z[l]*cunit1[n]} else {table$z2[rowsintable+s]<-0}
          
          table$diameter1[rowsintable+s]<-lie$diameter[prec]*cunit1[n]
          table$diameter2[rowsintable+s]<-lie$diameter[l]*cunit1[n]
          if ("Z" %in% colnames(lie)) {table$length[rowsintable+s]<-distance3D(x1=lie$X[prec], y1=lie$Y[prec], z1=lie$Z[prec], x2=lie$X[l], y2=lie$Y[l], z2=lie$Z[l])*cunit1[n]} else {table$length[rowsintable+s]<-distance2D(x1=lie$X[prec], y1=lie$Y[prec], x2=lie$X[l], y2=lie$Y[l])*cunit1[n]}
          table$blength[rowsintable+s]<-lie$dist[l]*cunit1[n]
          dirsegment<-c(lie$X[l]-lie$X[prec], lie$Y[l]-lie$Y[prec], lie$Z[l]-lie$Z[prec])*cunit1[n]
          table$orientation[rowsintable+s]<-acos(as.numeric(dirvert%*%dirsegment)/table$length[rowsintable+s])*cunitangle}}
      
      rowsintable<-rowsintable+s}}
  
  index<-which(is.na(table$file)==TRUE)
  table<-table[-index,] #Remove lines with NA values

  rownames(table)<-c(1:nrow(table))
  
  if (rsml.connect==TRUE) {table$geodesic<-table$dbasecum+table$blength}
  
  #Calculate growth rate of each segment and fill growth column
  sum<-aggregate(table$length, by=list(table$file, table$plant, table$time, table$root), sum)
  colnames(sum)<-c("file", "plant", "time", "root", "length")
  
  index<-as.vector(apply(table, 1, function(x){which(sum$file==x["file"] & sum$plant==as.numeric(x["plant"]) & sum$time==as.numeric(x["time"]) & sum$root==as.numeric(x["root"]))}))
  length1<-sum$length[index]
  table$growth<-length1/table$deltaage
  
  if (rsml.connect==TRUE) {table<-table[,-c(4,5,8)]}
  if (rsml.connect==FALSE) {table<-table[,-c(6)]}
  
  #Check if segments have length=0
    
  if (sum(table$length==0)>0){
    
    index<-which(table$length==0)
    
    for (i in 1:length(index)){
      
      indexsuiv<-which(table$file==table$file[index[i]] & table$root==table$root[index[i]] & table$x1==table$x2[index[i]] & table$y1==table$y2[index[i]] & table$z1==table$z2[index[i]])
      indexsuiv<-indexsuiv[indexsuiv!=index[i]]
      table$bran[indexsuiv]<-table$bran[index[i]]
      table$diameter1[indexsuiv]<-table$diameter1[index[i]]}
    
    table<-table[-index,]
    
    rownames(table)<-c(1:nrow(table))}
  
  if (rsml.connect==TRUE & fitter==TRUE){
  
  #Compute Fitter topological indices
  
  table$magnitude<-rep(0, nrow(table))
  table$pathlength<-rep(1, nrow(table))
  
  RSlevels<-levels(as.factor(table$file))
  n<-length(RSlevels)
  
  for (i in 1:n){#For each root system in the table
    
    subtable<-table[table$file==RSlevels[i],] #Create a subtable subset

    apicindex<-which(subtable$apic=="true") #apicindex and branindex should have the same length
    branindex<-which(subtable$bran=="true")

    for (l in 1:length(apicindex)){#For each apic point of a root system
      
      #Magnitude
      
      subtable$magnitude[apicindex[l]]<-1
      
      if (subtable$order[apicindex[l]]==1 & subtable$bran[apicindex[l]]=="true") {break}
      
      testbran<-which(subtable$x1==subtable$x1[apicindex[l]] & subtable$y1==subtable$y1[apicindex[l]] & subtable$z1==subtable$z1[apicindex[l]])
      
      if (length(testbran)==2){#We are at a crossing
        
        segment1<-which(subtable$x2==subtable$x1[apicindex[l]] & subtable$y2==subtable$y1[apicindex[l]] & subtable$z2==subtable$z1[apicindex[l]])
        segment2<-testbran[testbran!=apicindex[l]]
        geo1<-subtable$geodesic[segment1]
        geo2<-subtable$geodesic[segment2]
        if (geo1>geo2){indexprec<-segment2}
        if (geo1<geo2){indexprec<-segment1}}
      
      else {indexprec<-which(subtable$x2==subtable$x1[apicindex[l]] & subtable$y2==subtable$y1[apicindex[l]] & subtable$z2==subtable$z1[apicindex[l]])}
      
      subtable$magnitude[indexprec]<-subtable$magnitude[indexprec]+1
      
      while(subtable$order[indexprec]>=1){
        
        if (subtable$order[indexprec]==1 & subtable$bran[indexprec]=="true") {break}
        
        testbran<-which(subtable$x1==subtable$x1[indexprec] & subtable$y1==subtable$y1[indexprec] & subtable$z1==subtable$z1[indexprec])
        
        if (length(testbran)==2){#We are at a crossing
          
          segment1<-which(subtable$x2==subtable$x1[indexprec] & subtable$y2==subtable$y1[indexprec] & subtable$z2==subtable$z1[indexprec])
          segment2<-testbran[testbran!=indexprec]
          geo1<-subtable$geodesic[segment1]
          geo2<-subtable$geodesic[segment2]
          if (geo1>geo2){indexprec<-segment2}
          if (geo1<geo2){indexprec<-segment1}}
        
        else {indexprec<-which(subtable$x2==subtable$x1[indexprec] & subtable$y2==subtable$y1[indexprec] & subtable$z2==subtable$z1[indexprec])}
        
        subtable$magnitude[indexprec]<-subtable$magnitude[indexprec]+1}
    
      #Path length
  
      testbran<-which(subtable$x1==subtable$x2[branindex[l]] & subtable$y1==subtable$y2[branindex[l]] & subtable$z1==subtable$z2[branindex[l]])
      
      if (length(testbran)==2) {
        subtable$pathlength[testbran]<-subtable$pathlength[branindex[l]]+1
        index<-which(subtable$bran[testbran]=="false")
        suiv<-testbran[index]}
      else {
        subtable$pathlength[testbran]<-subtable$pathlength[branindex[l]]
        suiv<-testbran}
      
      while(subtable$apic[suiv]=="false"){
        
        testbran<-which(subtable$x1==subtable$x2[suiv] & subtable$y1==subtable$y2[suiv] & subtable$z1==subtable$z2[suiv])
        
        if (length(testbran)==2) {
          subtable$pathlength[testbran]<-subtable$pathlength[suiv]+1
          index<-which(subtable$bran[testbran]=="false")
          suiv<-testbran[index]}
        else {
          subtable$pathlength[testbran]<-subtable$pathlength[suiv]
          suiv<-testbran}}}
    
    table$magnitude[table$file==RSlevels[i]]<-subtable$magnitude
    table$pathlength[table$file==RSlevels[i]]<-subtable$pathlength}}

class(table)<-c("data.frame", "rsmlToTable")
return(table)}